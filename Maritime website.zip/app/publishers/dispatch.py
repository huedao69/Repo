import os, logging
from typing import List, Dict
from .wordpress import publish_wordpress
from .ghost import publish_ghost
from .email import send_email_if_configured

def publish_all(posts:List[Dict]):
    # Choose a publisher based on env or post type
    target = os.environ.get("PUBLISH_TARGET","wordpress")  # or "ghost" or "none"
    for p in posts:
        try:
            if target == "wordpress":
                publish_wordpress(p)
            elif target == "ghost":
                publish_ghost(p)
            else:
                pass
        except Exception as ex:
            logging.warning(f"Publish skip: {ex}")
    # Optionally send a digest email
    try:
        send_email_if_configured(posts)
    except Exception as ex:
        logging.warning(f"Email digest skip: {ex}")
