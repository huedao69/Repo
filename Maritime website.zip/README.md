# Auto Content System (ACS)

A mostly hands-off pipeline that turns messy public web information into monetizable content (newsletters, programmatic SEO pages, affiliate comparisons, and alerts).

**What it does**
- Ingests sources (RSS, sitemaps, pages) on a schedule
- Cleans & deduplicates content
- Classifies & extracts entities/topics
- Uses GPT to generate structured posts, newsletters, and comparison tables (with citations)
- Publishes to WordPress/Ghost, sends email, and pushes to social
- Tracks conversions (ads/affiliate) and subscriptions

> ⚠️ You are responsible for complying with each site's Terms of Service, robots.txt, and local laws. Only ingest content you have rights to use or summarize under fair-use.

## Quick start

1. Install Docker and Docker Compose.
2. Copy `.env.example` to `.env` and fill keys:
   - `OPENAI_API_KEY=`
   - `WORDPRESS_BASE_URL=`, `WORDPRESS_USERNAME=`, `WORDPRESS_APP_PASSWORD=` (if using WP)
   - `GHOST_ADMIN_API_URL=`, `GHOST_ADMIN_API_KEY=` (if using Ghost)
   - `MAILGUN_DOMAIN=`, `MAILGUN_API_KEY=` (or use SES/Sendgrid)
   - `REDIS_URL=redis://redis:6379/0`
3. `docker compose up --build`

By default, the scheduler runs every 2 hours to:
- crawl sources defined in `app/scraper/sources.yaml`
- process raw data into normalized JSON
- generate content using prompts in `app/config/prompts/`
- publish to the selected channels

## Opinionated monetization plays

- **Programmatic SEO**: evergreen topic+location+entity combinations -> static pages (ads + affiliate)
- **B2B leadgen newsletters**: e.g., maritime/port ops tenders and maintenance windows (subscriptions + sponsors)
- **Data/API product**: normalize public tariffs/fees into a simple API & dashboard (subscriptions)

## Local development

- Edit `app/scraper/sources.yaml` to add feeds/URLs you are allowed to use.
- Tweak prompts in `app/config/prompts/*.yaml` to match your niche.
- Run `docker compose run --rm app python -m app.main --once` to execute a single loop.

## Legal & Safety

- Respect robots.txt and TOS.
- Always cite sources in generated posts.
- Avoid medical/financial advice unless you add clear disclaimers and/or human review.
- Keep a throttled crawling rate; avoid disruptive scraping.

